# Handoff: RootLoot.ai Portal Redesign (all pages & tabs)

## Overview
This is a visual redesign of the **NutJob / RootLoot.ai** farm-management portal (AI-powered, multi-block, multi-crop farm operations). It covers the full app shell (sidebar + top nav + farm switcher) and all seven in-app pages, plus the pre-app Login and Farm-selector screens. The goal of this task: **reskin the existing Next.js codebase to match this design system**, replacing the current UI on every route while keeping all existing data-fetching, server actions, and business logic intact.

## About the design files
The attached `Dashboard.dc.html` is a **design reference prototype built in static HTML** (a "Design Component" — inline-styled, no framework). It is not production code and must not be copied in verbatim or embedded via iframe. Treat it as the pixel-accurate visual/interaction spec. Your job is to **recreate this design inside the real codebase** — Next.js App Router + TypeScript + Tailwind CSS v4 + Supabase — using the project's existing component patterns, data, and routes. Open the HTML file in a browser to inspect it directly; every color, spacing value, and copy string below was authored from that file and should match exactly.

`Dashboard.dc.html` is a single scrollable canvas containing, left to right: the Dashboard app (desktop, with working in-app tab routing across all 7 pages), a Mobile companion (Dashboard only), a Login screen, and a Farm-selector screen. Click the sidebar tabs in the desktop frame to see each page.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and copy below are final — recreate pixel-faithfully, adapted to Tailwind utility classes / CSS variables rather than inline styles.

---

## 1. Design tokens

### Color
Add these as CSS variables (Tailwind v4 `@theme` block in `app/globals.css`) rather than hardcoding hex values in components:

```css
@theme {
  /* neutrals */
  --color-paper: #F4F1E9;       /* app canvas background */
  --color-paper-2: #FBFAF5;     /* topbar / alt card background */
  --color-surface: #FFFFFF;     /* card background */
  --color-line: #E7E3D6;        /* borders */
  --color-line-soft: #F0EDE3;   /* dividers inside cards */
  --color-ink: #17251C;         /* primary text */
  --color-ink-2: #5F7266;       /* secondary text */
  --color-ink-3: #8A968C;       /* muted / mono labels */
  --color-ink-4: #A0AAA1;       /* faintest labels */

  /* sidebar (dark) */
  --color-sidebar-from: #15281D;
  --color-sidebar-to: #0F1F16;
  --color-sidebar-text: #B9C5BB;
  --color-sidebar-text-muted: #8C9A8F;

  /* brand */
  --color-green: #2F7D4F;       /* primary action, "healthy" status */
  --color-green-soft: #EAF3EC;
  --color-gold: #C4922E;        /* RootLoot brand accent */
  --color-gold-bright: #E7BE56; /* highlight / active nav / badges */
  --color-gold-soft: #F8F0DC;

  /* status / category */
  --color-blue: #3C7EA1;        /* water / irrigate / info */
  --color-blue-soft: #E9F1F5;
  --color-amber: #DDA02A;       /* "watch" status */
  --color-amber-soft: #FBF1DC;
  --color-red: #C24B39;         /* "critical" status */
  --color-red-soft: #F7E7E3;
  --color-purple: #8156A8;      /* spray category */
  --color-purple-soft: #F1EAF7;
  --color-teal: #2E8E8E;        /* pruning category */
  --color-teal-soft: #E4F1F1;
}
```

Status color mapping (used everywhere: block tiles, chips, dots): **Healthy → green**, **Watch → amber**, **Critical → red**. Category color mapping (recommendations, calendar, activity): **Irrigate → blue**, **Fertilize → gold**, **Spray → purple**, **Scout/Scouting → green**, **Pruning → teal**.

### Typography
Three Google Fonts, loaded via `next/font/google` or a `<link>` in the root layout:
- **Space Grotesk** (weights 500/600/700) — all headings, big metric numbers, page titles, farm/block names. Slightly technical/geometric, echoes the brand mark.
- **IBM Plex Sans** (weights 400/500/600/700) — all body copy, buttons, table cells, nav labels. This is the default body font.
- **IBM Plex Mono** (weights 400/500/600) — small caps labels (letter-spacing 0.5–2px, uppercase), source-attribution tags (`SENSOR`/`WEATHER`/`AI`/`COMPUTED`/`LAB`), timestamps, data units, keyboard-shortcut hints.

Type scale actually used: 26px/700 (page titles), 18–20px/700 (card/section titles, block codes), 15–16px/600 (card headings), 13–14.5px/500–600 (body/labels), 12–12.5px (secondary text), 9.5–11px (mono micro-labels).

### Icons
**Material Symbols Rounded** (variable font) via Google Fonts: `family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..0`. Icons are rendered as text ligatures (e.g. a `<span>` containing the literal string `water_drop` renders a water-drop glyph), with `font-variation-settings: 'FILL' 0 or 1` to switch outline vs. filled (filled = active/emphasis state). If the target stack already uses an icon library (e.g. lucide-react, which is common in shadcn-based Next.js apps), you may substitute equivalent icons 1:1 instead of pulling in this font — keep sizes matched (17–24px depending on context).

### Radii & shape
- Cards / panels: **16px**
- Small tiles (block cards, KPI mini-cards): **13–14px**
- Buttons, inputs, dropdown triggers: **10–12px**
- Pills / chips / badges: **20px** (full pill) or **5–7px** (small rectangular tag)
- Sidebar nav items: **11px**
- Avatars / icon swatches: **8–13px** depending on size (never circular except status dots and user-initial avatars, which vary)

### Elevation
Cards are flat (`1px solid var(--color-line)`, no shadow) — hierarchy comes from color and spacing, not shadow. Reserve shadow for **floating/overlay elements only**: dropdown menus (`box-shadow: 0 20-22px 50px -12px rgba(20,37,27,.35-.4)`) and primary buttons (`box-shadow: 0 6-8px 16-18px -4-5px rgba(47,125,79,.5-.55)`).

### Spacing
4px base scale. Card padding 18–20px. Gaps between cards/sections 14–16px. Sidebar item padding 9px 12px. Table cell padding 13–14px 18px.

---

## 2. App shell (present on every in-app page)

### Sidebar (left, fixed, ~238px wide)
- Background: linear-gradient 185deg, `--color-sidebar-from` → `--color-sidebar-to`.
- Top: RootLoot.ai logo lockup (gem mark + wordmark, white version — see Assets) + a small 2-line mono label ("FARM / OPS").
- Nav groups, each with a mono uppercase group label (`OPERATIONS`, `RECORDS`):
  - **Operations**: Dashboard, Blocks, Calendar, Recommendations (with a gold pill badge showing open-recommendation count, e.g. "3")
  - **Records**: Activity log, Inventory, Settings
- Nav item states: inactive = transparent bg, icon `--color-sidebar-text-muted`, label `--color-sidebar-text` weight 500. **Active** = background `rgba(231,190,86,.15)` (gold at 15% opacity), icon `--color-gold-bright` filled, label white weight 600. Hover (inactive) = `rgba(255,255,255,.05)` background.
- Bottom of sidebar: an "AI engine active" status chip (green-tinted background, pulsing green dot, "synced N min ago" mono subtext) sitting above a user profile row (avatar initial in a gradient swatch, name, mono role label e.g. "FARM ADMIN", overflow-menu icon).

### Top bar (~64px tall, `--color-paper-2` background, bottom border)
Left to right:
1. **Farm switcher** (this is the multi-farm control — must work from any page without re-authenticating, per requirements): a pill button showing a colored farm-initial avatar, farm name (bold), and a mono meta line ("ADMIN · 9 BLOCKS · 5.2 HA"), with a chevron/unfold icon. Clicking opens a dropdown (white card, radius 14px, elevated shadow) listing all farms the user has access to (each row: avatar, name, role/block-count meta, checkmark on the active one) plus a "Create new farm" row at the bottom. Selecting a farm updates the switcher and closes the menu.
2. Search field (placeholder "Search blocks, events, activity…", with a `⌘K` hint on the right).
3. Flexible spacer.
4. Current-weather mini chip (icon + temp + condition).
5. Notification bell (badge dot when unread).
6. Language/translate icon button (for the EN/AR/TR locale switch — see Localization below).

---

## 3. Pages

For each page below, note the likely existing route in the repo (from partial repo inspection — **verify actual file paths before editing**, some may need to be created):

### 3.1 Login — `app/(auth)/login/page.tsx`
Two-panel layout, ~split 46/54, rounded outer container in the prototype (in the real app this is likely the full viewport, centered or full-bleed — use judgement based on existing auth layout).
- **Left panel** (dark, `--color-sidebar-from`→`-to` gradient): logo lockup (light/white version), large Space Grotesk headline ("Grow with intelligence." — 2 lines), supporting sentence, 3 small brand-color dots as a decorative accent, small mono copyright line at the bottom, one soft radial gold glow decorative blob top-right.
- **Right panel** (`--color-paper-2`): "Sign in" title + subtitle, Email field (icon + input), Password field (icon + input + show/hide toggle), Remember-me checkbox + "Forgot password?" link on one row, full-width primary green Sign-in button with arrow icon, an "OR" divider, a secondary "Continue with SSO" button, and a small mono footnote: "ROLE-BASED ACCESS · ADMIN · SUPERVISOR · WORKER" (reflecting the three permission tiers in the requirements).

### 3.2 Farm selector (post-login, shown when a user has 2+ farms)
Likely route: wherever the app currently gates farm selection before `/[farmId]/dashboard` (may not exist yet as a distinct page — check `app/[farmId]/(dashboard)/layout.tsx` and root `app/page.tsx`).
- Top bar: logo (dark version) + current user (avatar + name) + "Log out".
- Heading "Choose a farm" + subtitle noting they can switch anytime from the top bar.
- 2-column grid of farm cards (one per accessible farm) + a dashed "Create a new farm" card.
- Each farm card: colored initial avatar, role pill (Admin/Worker) top-right, farm name (Space Grotesk 18px), mono meta line (blocks · hectares · region), a row of small health-status dots + a summary label ("2 ALERTS" / "ALL HEALTHY" / "1 WATCH"), and a footer row ("Last active …" + "Open →" in the farm's accent color).

### 3.3 Dashboard — `app/[farmId]/(dashboard)/dashboard/page.tsx`
- Greeting row: "Good {morning/afternoon/evening}, {name}" (Space Grotesk 26px) + date/season subtitle + right-aligned "Add event" (secondary) and "Log activity" (primary) buttons.
- **4 KPI cards** in a row: Avg Soil Moisture (%, progress bar, trend chip), Water Deficit/ETo (mm/day, mini bar-sparkline, "WATCH" chip), Growing Degree Days (progress bar toward season target), Active Alerts (count + severity dot bar). Each card: icon + mono label top, big Space Grotesk number, small mono footnote.
- **7-day weather strip**: horizontal row of 7 day-columns (mono day label, weather icon, hi/lo temp, rain% + wind mono), with a rain/frost-warning chip in the card header.
- **Two-column body** (≈62/38 split):
  - Left: **Block health** card — header with view toggle (Grid/Map segmented control) — 3×3 grid of block tiles (code, status dot, crop · variety, area/age mono, a 5-segment "domain" mini-bar for soil/phenology/nutrition/pest/weather) — plus a **Priority actions** card (AI icon + "N NEW" badge) containing 1–2 recommendation cards (category icon+chip, block mono tag, title, rationale, confidence bar+%, Skip/Edit/Accept controls).
  - Right, stacked: **Active alerts** (severity-colored left bar, title, source+time mono meta), **Upcoming** (calendar month/day mono block, colored dot by category, title, meta), **Recent activity** (timeline with icon-in-swatch, actor+action text, mono meta).

### 3.4 Blocks — `app/[farmId]/(dashboard)/blocks/page.tsx`
Requirements: upload a real farm map, divide into physical blocks, show type/variety per block, and a full live profile across 5 agronomic domains with source attribution.
- Header + "Draw boundaries" (secondary) / "Add block" (primary) actions.
- **Left (60%): Map card** — layer-select pill ("Satellite ▾"), Manual/Satellite segmented toggle, and the map area itself: in the prototype this is a striped placeholder labeled "DROP FARM SATELLITE MAP" with pill markers per block scattered over it (colored by status) plus a farm-location marker. **In the real app, replace the placeholder with the actual uploaded map image and drawn block polygons** (this is real functionality to build, not decoration) — clicking a block pin/polygon selects it and updates the right panel.
- **Right (40%): Selected block profile** — a header card (block code avatar, crop · variety, status chip, planted year, then a 3-up mini-stat row: area / trees / rootstock) followed by **5 stacked domain cards**: Soil & Water, Phenology, Nutrition, Pest & Disease, Weather. Each domain card: icon+title, a status chip (GOOD/ON TRACK/WATCH/ALERT, color-matched), 1–2 lines of key metrics or an inline alert box, and a mono "SOURCE · X · timestamp" attribution line (source values: SENSOR, WEATHER API, COMPUTED, LAB TISSUE TEST, AI).

### 3.5 Calendar — `app/[farmId]/(dashboard)/calendar/page.tsx`
- Header + Today/Add-event actions.
- Toolbar row inside the calendar card: Month/Week/Day segmented control (Month active by default), prev/today/next month navigator, and a mono color-key legend (Irrigation=blue, Fertigation=gold, Spray=purple, Scouting=green).
- **Month grid**: 7-column weekday header (locale week-start — see Localization) + 5 rows × 7 day cells. Leading/trailing out-of-month days are muted (lighter background, faint numeral). Today's cell gets a soft green tint + bordered highlight + bold numeral. Each cell can hold multiple small event chips (colored dot + label, truncated).
- Per the requirements, event content should encode: irrigation (time, run-hours, litres/tree), fertigation (timing, fertilizer type by growth stage, amount), spraying (timing, pesticide type by pest/disease pressure, amount), pruning (timing/type after harvest, Nov–Feb). Clicking a day or event should open an add/edit/complete flow (not in the static prototype — build as a modal/drawer using existing patterns).

### 3.6 Recommendations — `app/[farmId]/(dashboard)/recommendations/page.tsx`
- Header + a small "updated N min ago" live-status indicator.
- **Filter chip row**: All / Irrigate / Fertilize / Spray / Scout — pill buttons, active = solid green fill + white text, inactive = white bg + line border + muted text. Filtering is client-side state, instant.
- **2-column card grid**, one card per recommendation: category icon in a color-matched swatch, category chip + block mono tag, title (bold), rationale (muted, 2–3 lines), footer with a confidence bar + percentage (color-coded: green ≥85%, amber <85%) and **Skip / Edit / Accept** controls (Skip = plain text button, Edit = outlined button, Accept = solid green button with check icon).

### 3.7 Activity log — `app/[farmId]/(dashboard)/activity/page.tsx`
- Header + Export action.
- Filter bar: search field + "All activities" / "All blocks" / "Last 7 days" dropdown triggers (functional filters to wire up).
- **Table** (header row on `--color-paper` tint, then rows): Date/Time (mono) · Block (bold, em-dash if farm-wide) · Activity type (colored chip matching category palette — add Pruning=teal, Tissue sample=purple, Sensor sync=grey/neutral) · Logged by · Details (muted) · Status chip (Logged=green, Completed=blue, Pending=amber, Auto=grey).

### 3.8 Inventory — `app/[farmId]/(dashboard)/inventory/page.tsx` (route likely needs to be created — only `actions.ts` exists at the non-farm-scoped `app/(dashboard)/inventory/` path currently)
- Header + "Add item" primary action.
- **4 KPI cards**: Consumables value ($), Low stock (count, red-tinted card), Assets (count), Maintenance due (count, amber-tinted card).
- **Consumables table** card: Item · Category chip (Fertilizer=gold, Pesticide=purple) · Stock (inline progress bar + quantity, bar colored green/amber/red by level relative to reorder point) · Reorder-at threshold (mono) · Status chip (OK=green / LOW=red). Low-stock rows get a faint red row tint.
- **Assets & equipment table** card: Asset name · Type · Last service date (mono) · Next service date (mono, amber if due) · Status chip (OK=green / DUE=amber).
- Per requirements: consumable usage should link to calendar events (e.g. a fertigation event decrements fertilizer stock) — this is real logic to wire, not shown in the static prototype.

### 3.9 Settings — `app/[farmId]/(dashboard)/settings/page.tsx`
- Header.
- **Left sub-nav** (230px, card container): Block configuration, Sensor connections, Weather API, Irrigation controller, Notifications, **Team & users** (shown active/selected in the reference — style: gold-tinted row, green filled icon, semibold green text).
- **Right panel** (shown for the Team & users tab in the reference; build equivalent panels for the other 5 tabs using the same card/table language):
  - Team & users card: header + "Invite" button, then a table — Member (avatar + name + email) · Role (pill: Admin=green-tinted, Supervisor=amber-tinted, Worker=grey-tinted — matches the three permission tiers in the requirements) · Farm access (which farm(s)) · Status (● Active green / ● Pending amber).
  - Notifications card: a list of toggle rows (label + description + iOS-style pill switch, green when on) — Critical alerts, Weather warnings, AI recommendations, Weekly summary.

---

## 4. Reusable components (build these once, use everywhere)

- **StatusChip**: pill, colored text on colored-soft background, mono, e.g. `HEALTHY`/`WATCH`/`CRITICAL`, `OK`/`LOW`, `GOOD`/`ON TRACK`/`ALERT`.
- **CategoryChip**: same visual language for activity/recommendation categories (irrigate/fertilize/spray/scout/prune), color-mapped per §1.
- **PrimaryButton** (solid green gradient, white text, icon-left, soft green shadow) / **SecondaryButton** (white, bordered, dark text) / **GhostButton** (text-only, muted, used for "Skip"/table row actions).
- **Card** (white, `--color-line` border, 16px radius, 18–20px padding — no shadow).
- **KPICard** (Card + mono label/icon row + big Space Grotesk number + progress/sparkline + mono footnote).
- **ConfidenceBar** (6px rounded track, colored fill by %, used in Recommendations).
- **DomainStatusCard** (used in Blocks: icon+title+status chip+metrics+source-attribution line).
- **NavItem** (sidebar; active/inactive/hover states per §2).
- **FarmSwitcher** (topbar dropdown per §2 — this is a shared, cross-page control; implement once in the shell layout).
- **CalendarCell / EventChip** (per §3.5).
- **DataTable row** patterns for Activity log / Inventory / Settings-team (consistent column padding, header row on tinted background, status chip in the last column).
- **ToggleSwitch** (pill, green when on, grey when off — Settings notifications).

## 5. Interactions & behavior
- Sidebar nav is client-side routing (Next.js `<Link>`/`useRouter`) between the farm-scoped routes; active state derives from the current pathname, not local component state.
- Farm switcher: dropdown open/close is local UI state; selecting a farm should navigate to `/[newFarmId]/dashboard` (or preserve the current page if that route exists for the new farm) **without a full re-authentication**, per requirements.
- Recommendations filter chips: client-side filter, no page reload.
- Block map: clicking a block pin/polygon updates the selected-block profile panel (client state); this should be driven by real block data from Supabase, not hardcoded.
- Accept/Edit/Skip on a recommendation card should call the corresponding server action (see `app/[farmId]/(dashboard)/recommendations/actions.ts`) and optimistically update/remove the card.
- All interactive elements (buttons, chips, table rows with actions) need visible hover and focus states — see the color/opacity deltas noted inline above (e.g. sidebar hover = `rgba(255,255,255,.05)`, button hover = `filter: brightness(1.05)` or border-color darken).

## 6. Localization (EN / AR / TR)
The repo already has `messages/en.json`, `messages/ar.json`, `messages/tr.json` and `i18n/` config (next-intl or similar) — **reuse the existing i18n setup**, don't hardcode strings. Arabic requires full RTL mirroring: sidebar moves to the right, icon/text order flips, chevrons flip direction, calendar week-start and number formatting follow locale. Test every page above in RTL, especially the two-column Dashboard/Blocks layouts and the farm-switcher dropdown alignment.

## 7. Mobile / responsive
Below a phone breakpoint, replace the sidebar with a **bottom navigation bar** (5 items: Dashboard/Home, Blocks, a centered raised gold "+" FAB for quick-add, Recommendations/AI, Activity), and stack the topbar into a compact farm-switcher pill + notification bell. KPIs go to a 2×2 grid, the weather strip becomes horizontally scrollable, and the block-health grid becomes a simple list. All tap targets ≥ 44×44px. See the "Mobile companion" frame in `Dashboard.dc.html` for the exact Dashboard treatment — apply the same density/pattern rules to the other pages.

## 8. Assets
- `assets/logo-light.png` — RootLoot.ai wordmark + gem/circuit mark, white version, **for dark backgrounds** (sidebar, login left panel).
- `assets/logo-dark.png` — same mark, dark/charcoal version, **for light backgrounds** (topbar, farm selector, printed contexts).
  Both are trimmed of transparent padding; scale by height (58–70px typical), width auto.
- Fonts: Google Fonts — `Space+Grotesk:wght@400;500;600;700`, `IBM+Plex+Sans:wght@400;500;600;700`, `IBM+Plex+Mono:wght@400;500;600`, `Material+Symbols+Rounded` (variable, opsz/wght/FILL/GRAD axes).
- No other custom imagery — map imagery, farm photos, and user avatars are real content to be supplied by the app (uploaded farm map, user profile photos), not design assets.

## 9. Files in this handoff
- `README.md` — this document.
- `Dashboard.dc.html` — the interactive HTML prototype (open in any browser). Contains, as one scrollable canvas: the full desktop app with working tab navigation across all 7 in-app pages, a mobile companion view, and the Login and Farm-selector screens.
- `assets/logo-light.png`, `assets/logo-dark.png` — brand mark, both orientations.
